const express = require('express');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Explicitly serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Example API endpoint (optional)
app.get('/api/products', (req, res) => {
    res.json([{ id: 1, name: "Product A" }, { id: 2, name: "Product B" }]);
});

// Fallback to serve index.html for all other routes
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
console.log(path.join(__dirname, 'public', 'index.html'));
const mongoose = require('mongoose');

// Connect to MongoDB (replace with your own MongoDB URI if using MongoDB Atlas)
mongoose.connect('mongodb://localhost:27017/ecommerceDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

mongoose.connection.once('open', () => {
    console.log('Connected to MongoDB');
}).on('error', (error) => {
    console.log('Error connecting to MongoDB:', error);
});
